import os


def init_env():
    os.environ['DATA_PATH'] = ''
    os.environ['OUT_PATH'] = ''
