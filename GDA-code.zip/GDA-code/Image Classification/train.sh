export GPU_NUMS=6
export PORT=25060
export TEACHER=resnet56
export STUDENT=resnet20
export TEACHER_PRETRAINED=cache/ckpt/cifar/resnet56_72.94.pth
export DISTILLER=kd
export GT_WEIGHT=2.0
export KD_WEIGHT=1.0
export FISHER_RAO_LAMDA=0.02
export SINKHORN_LAMDA=0.1
export TEMPERATURE=4.0
export OUTPUT=cache/output/resnet56_resnet20_kd_sinkhorn
export SAVE_NAME=logs/resnet56_resnet20_kd_sinkhorn.logs
python -m torch.distributed.launch --nproc_per_node=$GPU_NUMS --master_port=$PORT train.py --data_dir cache/data/cifar/ --config configs/cifar_v0.yaml --model $STUDENT --distiller $DISTILLER --output $OUTPUT --teacher $TEACHER --teacher-pretrained $TEACHER_PRETRAINED \
--gt-loss-weight $GT_WEIGHT --kd-loss-weight $KD_WEIGHT --fisher-rao-lamda $FISHER_RAO_LAMDA --sinkhorn-lamda $SINKHORN_LAMDA --kd-temperature $TEMPERATURE \
> $SAVE_NAME 2>&1 &