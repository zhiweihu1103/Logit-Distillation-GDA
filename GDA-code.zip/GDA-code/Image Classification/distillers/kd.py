import torch
import torch.nn as nn
import torch.nn.functional as F

from ._base import BaseDistiller
from .registry import register_distiller
from .utils import kd_loss

def normalize(logit):
    mean = logit.mean(dim=-1, keepdims=True)
    stdv = logit.std(dim=-1, keepdims=True)
    return (logit - mean) / (1e-7 + stdv)

class FishRao_Sinkhorn(nn.Module):
    def __init__(self, fisher_rao_lamda=0.01, sinkhorn_lamda=0.0008, epsilon=0.1, n_iters=20, T=2):
        super(FishRao_Sinkhorn, self).__init__()
        self.sinkhorn_lamda = sinkhorn_lamda
        self.fisher_rao_lamda = fisher_rao_lamda
        self.epsilon = epsilon
        self.n_iters = n_iters
        self.T = T

    def sinkhorn_normalized(self, x, n_iters):
        for _ in range(n_iters):
            x = x / torch.sum(x, dim=1, keepdim=True)
            x = x / torch.sum(x, dim=0, keepdim=True)
        return x

    def sinkhorn_loss(self, x, y):
        Wxy = torch.cdist(x, y, p=1)
        K = torch.exp(-Wxy / self.epsilon)
        P = self.sinkhorn_normalized(K, self.n_iters)
        return torch.sum(P * Wxy)

    def fisher_rao_loss(self, x, y):
        mean_x, std_x = x.mean(dim=-1), x.std(dim=-1)
        mean_y, std_y = y.mean(dim=-1), y.std(dim=-1)
        mean_sub = (mean_x - mean_y).pow(2)
        std_sub = (std_x - std_y).pow(2)
        std_add = (std_x + std_y).pow(2)
        fisher_rao_distance = 2*torch.sqrt(torch.tensor(2))*torch.atanh(torch.sqrt((mean_sub + 2*std_sub)/(mean_sub + 2*std_add)))

        return fisher_rao_distance.mean()

    def forward(self, y_s, y_t):
        fr_loss = self.fisher_rao_lamda * self.fisher_rao_loss(y_s, y_t)
        softmax = nn.Softmax(dim=1)
        y_s = normalize(y_s)
        y_t = normalize(y_t)
        p_s = softmax(y_s / self.T)
        p_t = softmax(y_t / self.T)
        emd_loss = self.sinkhorn_lamda * self.sinkhorn_loss(x=p_s, y=p_t)
        total_loss = emd_loss + fr_loss

        return total_loss


@register_distiller
class KD(BaseDistiller):
    requires_feat = False
    def __init__(self, student, teacher, criterion, args, **kwargs):
        super(KD, self).__init__(student, teacher, criterion, args)

        self.sinkhorn_fisher_rao = FishRao_Sinkhorn(fisher_rao_lamda=args.fisher_rao_lamda, sinkhorn_lamda=args.sinkhorn_lamda)

    def forward(self, image, label, *args, **kwargs):
        with torch.no_grad():
            self.teacher.eval()
            logits_teacher = self.teacher(image)

        logits_student = self.student(image)

        # baseline
        # loss_gt = self.args.gt_loss_weight * self.criterion(logits_student, label)
        # loss_kd = self.args.kd_loss_weight * kd_loss(logits_student, logits_teacher, self.args.kd_temperature)
        # losses_dict = {
        #     "loss_gt": loss_gt,
        #     "loss_kd": loss_kd,
        # }

        # with label sinkhorn
        loss_gt = self.args.gt_loss_weight * self.criterion(logits_student, label)
        loss_kd = self.args.kd_loss_weight * kd_loss(logits_student, logits_teacher, self.args.kd_temperature)
        loss_sinkhorn_fisher_rao = self.sinkhorn_fisher_rao(logits_student, logits_teacher)
        losses_dict = {
            "loss_gt": loss_gt,
            "loss_kd": loss_kd + loss_sinkhorn_fisher_rao,
        }

        # without label baseline
        # soft_targets = F.softmax(logits_teacher, dim=-1)
        # loss_gt = self.args.gt_loss_weight * self.criterion(logits_student, soft_targets)
        # loss_kd = self.args.kd_loss_weight * kd_loss(logits_student, logits_teacher, self.args.kd_temperature)
        # losses_dict = {
        #     "loss_gt": loss_gt,
        #     "loss_kd": loss_kd,
        # }

        # without label sinkhorn
        # soft_targets = F.softmax(logits_teacher, dim=-1)
        # loss_gt = self.args.gt_loss_weight * self.criterion(logits_student, soft_targets)
        # loss_kd = self.args.kd_loss_weight * kd_loss(logits_student, logits_teacher, self.args.kd_temperature)
        # loss_sinkhorn_fisher_rao = self.sinkhorn_fisher_rao(logits_student, logits_teacher)
        # losses_dict = {
        #     "loss_gt": loss_gt,
        #     "loss_kd": loss_kd + loss_sinkhorn_fisher_rao,
        # }

        return logits_student, losses_dict