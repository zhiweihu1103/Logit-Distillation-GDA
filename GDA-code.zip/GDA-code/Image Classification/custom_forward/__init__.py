from .mobilenetv1 import *
from .resnet import *
from .cifar import *

from .registry import register_new_forward
